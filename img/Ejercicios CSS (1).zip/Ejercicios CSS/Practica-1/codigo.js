		var nombre="Alejandro";
		var peso =85;
		var altura= 1.85;
	 alert("Mi nombre es "+nombre+ " mi altura "+altura);